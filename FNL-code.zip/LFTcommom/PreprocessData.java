package LFTcommom;
import java.io.*;
import java.util.*;

public class PreprocessData {
    // 计算均值和标准差
    private static double[] computeStats(String[] files) throws IOException {
        List<Double> values = new ArrayList<>();
        for (String file : files) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split("::");
                    double value = Double.parseDouble(parts[3]);
                    values.add(value);
                }
            }
        }
        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double std = Math.sqrt(values.stream().mapToDouble(v -> Math.pow(v - mean, 2)).average().orElse(1.0));
        return new double[]{mean, std};
    }

    // 标准化并保存新文件
    private static void normalizeAndSave(String inputFile, String outputFile, double mean, double std) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             PrintWriter pw = new PrintWriter(new FileWriter(outputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("::");
                int x = Integer.parseInt(parts[0]);
                int y = Integer.parseInt(parts[1]);
                int z = Integer.parseInt(parts[2]);
                double value = Double.parseDouble(parts[3]);
                double normalizedValue = (value - mean) / std; // 标准化
                pw.printf("%d::%d::%d::%.10f%n", x, y, z, normalizedValue);
            }
        }
    }

    public static void main(String[] args) {
        String[] inputFiles = {
                "C:\\Users\\25776\\Desktop\\HFINL初稿\\dataset\\D3\\6a_2_tr5.txt",
                "C:\\Users\\25776\\Desktop\\HFINL初稿\\dataset\\D3\\6a_2_val5.txt",
                "C:\\Users\\25776\\Desktop\\HFINL初稿\\dataset\\D3\\6a_2_te90.txt"
        };
        String[] outputFiles = {
                "C:\\Users\\25776\\Desktop\\HFINL初稿\\dataset\\D3\\6a_2_tr5_normalized.txt",
                "C:\\Users\\25776\\Desktop\\HFINL初稿\\dataset\\D3\\6a_2_val5_normalized.txt",
                "C:\\Users\\25776\\Desktop\\HFINL初稿\\dataset\\D3\\6a_2_te90_normalized.txt"
        };

        try {
            // 计算全局均值和标准差
            double[] stats = computeStats(inputFiles);
            double mean = stats[0];
            double std = stats[1];
            System.out.printf("Global mean: %.6f, std: %.6f%n", mean, std);

            // 标准化并生成新文件
            for (int i = 0; i < inputFiles.length; i++) {
                normalizeAndSave(inputFiles[i], outputFiles[i], mean, std);
                System.out.printf("Generated normalized file: %s%n", outputFiles[i]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}