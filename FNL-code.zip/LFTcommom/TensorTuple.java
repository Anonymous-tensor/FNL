package LFTcommom;
public class TensorTuple {
    public int x, y, z;
    public double value;

    public TensorTuple(int x, int y, int z, double value) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.value = value;
    }
}