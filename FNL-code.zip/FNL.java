import LFTcommom.TensorTuple;
import java.io.*;
import java.util.*;

public class FNL {
    private static final int R = 10; // 隐特征维度
    private static final int MAX_ITER = 1000;
    private static final double TOL = 1e-5;
    private static final int PATIENCE = 5;
    private static final int MIN_ITER = 5;

    // Hard sigmoid 函数
    private static double hardSigmoid(double x) {
        return Math.max(0, Math.min(1, 0.2 * x + 0.5));
    }

    // 读取预归一化后的张量文件
    private static List<TensorTuple> readTensorFile(String filename) throws IOException {
        List<TensorTuple> tuples = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("::");
                int x = Integer.parseInt(parts[0]);
                int y = Integer.parseInt(parts[1]);
                int z = Integer.parseInt(parts[2]);
                double value = Double.parseDouble(parts[3]);
                tuples.add(new TensorTuple(x, y, z, value));
            }
        }
        return tuples;
    }

    // 获取张量维度
    private static int[] getTensorDims(List<TensorTuple> trainTuples, List<TensorTuple> validTuples, List<TensorTuple> testTuples) {
        int maxX = 0, maxY = 0, maxZ = 0;
        for (TensorTuple t : trainTuples) {
            maxX = Math.max(maxX, t.x + 1);
            maxY = Math.max(maxY, t.y + 1);
            maxZ = Math.max(maxZ, t.z + 1);
        }
        for (TensorTuple t : validTuples) {
            maxX = Math.max(maxX, t.x + 1);
            maxY = Math.max(maxY, t.y + 1);
            maxZ = Math.max(maxZ, t.z + 1);
        }
        for (TensorTuple t : testTuples) {
            maxX = Math.max(maxX, t.x + 1);
            maxY = Math.max(maxY, t.y + 1);
            maxZ = Math.max(maxZ, t.z + 1);
        }
        System.out.printf("Computed dims: %d x %d x %d%n", maxX, maxY, maxZ);
        System.out.printf("Max z in train: %d, valid: %d, test: %d%n",
                trainTuples.stream().mapToInt(t -> t.z).max().getAsInt(),
                validTuples.stream().mapToInt(t -> t.z).max().getAsInt(),
                testTuples.stream().mapToInt(t -> t.z).max().getAsInt());
        return new int[]{maxX, maxY, maxZ};
    }

    // 验证坐标
    private static boolean validateTuples(List<TensorTuple> tuples, int maxX, int maxY, int maxZ, String datasetName) {
        for (int i = 0; i < tuples.size(); i++) {
            TensorTuple t = tuples.get(i);
            if (t.x >= maxX || t.y >= maxY || t.z >= maxZ) {
                System.out.printf("Invalid tuple in %s at index %d: (%d, %d, %d) exceeds (%d, %d, %d)%n",
                        datasetName, i, t.x, t.y, t.z, maxX, maxY, maxZ);
                return false;
            }
        }
        return true;
    }

    // 计算 RMSE 和 MAE
    private static double[] computeRMSEandMAE(List<TensorTuple> tuples, double[][] U, double[][] W, double[][] Z) {
        double errorSqSum = 0, errorAbsSum = 0;
        for (TensorTuple t : tuples) {
            double pred = 0;
            for (int r = 0; r < R; r++) {
                pred += hardSigmoid(U[t.x][r]) * hardSigmoid(W[t.y][r]) * hardSigmoid(Z[t.z][r]);
            }
            double error = t.value - pred;
            errorSqSum += error * error;
            errorAbsSum += Math.abs(error);
        }
        double rmse = Math.sqrt(errorSqSum / tuples.size());
        double mae = errorAbsSum / tuples.size();
        return new double[]{rmse, mae};
    }

    // 梯度计算（混合 RMSE 和 MAE）
    private static double[][] computeGradientU(List<TensorTuple> tuples, double[][] U_look, double[][] W, double[][] Z, double lambda_t) {
        double[][] gradU = new double[U_look.length][R];
        double[] S_look = new double[U_look.length * R];
        for (int i = 0; i < U_look.length; i++) {
            for (int r = 0; r < R; r++) {
                S_look[i * R + r] = hardSigmoid(U_look[i][r]);
            }
        }
        for (TensorTuple t : tuples) {
            double pred = 0;
            for (int r = 0; r < R; r++) {
                pred += S_look[t.x * R + r] * hardSigmoid(W[t.y][r]) * hardSigmoid(Z[t.z][r]);
            }
            double error = t.value - pred;
            double gradRMSE = -2 * error;
            double gradMAE = -Math.signum(error);
            double combinedGrad = 0.5 * gradRMSE + 0.5 * gradMAE;
            for (int r = 0; r < R; r++) {
                double gradS = combinedGrad * hardSigmoid(W[t.y][r]) * hardSigmoid(Z[t.z][r]) + 2 * lambda_t * S_look[t.x * R + r];
                gradU[t.x][r] += gradS * (U_look[t.x][r] > -2.5 && U_look[t.x][r] < 2.5 ? 0.2 : 0);
            }
        }
        return gradU;
    }

    private static double[][] computeGradientW(List<TensorTuple> tuples, double[][] W_look, double[][] U, double[][] Z, double lambda_t) {
        double[][] gradW = new double[W_look.length][R];
        double[] D_look = new double[W_look.length * R];
        for (int j = 0; j < W_look.length; j++) {
            for (int r = 0; r < R; r++) {
                D_look[j * R + r] = hardSigmoid(W_look[j][r]);
            }
        }
        for (TensorTuple t : tuples) {
            double pred = 0;
            for (int r = 0; r < R; r++) {
                pred += hardSigmoid(U[t.x][r]) * D_look[t.y * R + r] * hardSigmoid(Z[t.z][r]);
            }
            double error = t.value - pred;
            double gradRMSE = -2 * error;
            double gradMAE = -Math.signum(error);
            double combinedGrad = 0.5 * gradRMSE + 0.5 * gradMAE;
            for (int r = 0; r < R; r++) {
                double gradD = combinedGrad * hardSigmoid(U[t.x][r]) * hardSigmoid(Z[t.z][r]) + 2 * lambda_t * D_look[t.y * R + r];
                gradW[t.y][r] += gradD * (W_look[t.y][r] > -2.5 && W_look[t.y][r] < 2.5 ? 0.2 : 0);
            }
        }
        return gradW;
    }

    private static double[][] computeGradientZ(List<TensorTuple> tuples, double[][] Z_look, double[][] U, double[][] W, double lambda_t) {
        double[][] gradZ = new double[Z_look.length][R];
        double[] T_look = new double[Z_look.length * R];
        for (int k = 0; k < Z_look.length; k++) {
            for (int r = 0; r < R; r++) {
                T_look[k * R + r] = hardSigmoid(Z_look[k][r]);
            }
        }
        for (TensorTuple t : tuples) {
            double pred = 0;
            for (int r = 0; r < R; r++) {
                pred += hardSigmoid(U[t.x][r]) * hardSigmoid(W[t.y][r]) * T_look[t.z * R + r];
            }
            double error = t.value - pred;
            double gradRMSE = -2 * error;
            double gradMAE = -Math.signum(error);
            double combinedGrad = 0.5 * gradRMSE + 0.5 * gradMAE;
            for (int r = 0; r < R; r++) {
                double gradT = combinedGrad * hardSigmoid(U[t.x][r]) * hardSigmoid(W[t.y][r]) + 2 * lambda_t * T_look[t.z * R + r];
                gradZ[t.z][r] += gradT * (Z_look[t.z][r] > -2.5 && Z_look[t.z][r] < 2.5 ? 0.2 : 0);
            }
        }
        return gradZ;
    }

    // 优化超参数调整
    private static double[] adjustHyperparams(double I_t) {
        double[] I = {0.00001, 0.0001, 0.001, 0.01, 0.1, 1};
        double[] etaVals = {0.25, 0.125, 0.0625, 0.00375, 0.001875, 0.0009375};
        double[] lambdaVals = {1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1};
        double[] gammaVals = {0.85, 0.84, 0.83, 0.82, 0.81, 0.80};

        if (I_t <= I[0]) return new double[]{etaVals[0], lambdaVals[0], gammaVals[0]};
        if (I_t > I[I.length - 1]) return new double[]{etaVals[I.length - 1], lambdaVals[I.length - 1], gammaVals[I.length - 1]};
        for (int idx = 0; idx < I.length - 1; idx++) {
            if (I[idx] < I_t && I_t <= I[idx + 1]) {
                double deg1 = (I_t - I[idx]) / (I[idx + 1] - I[idx]);
                double deg2 = 1 - deg1;
                return new double[]{
                        deg2 * etaVals[idx] + deg1 * etaVals[idx + 1],
                        deg2 * lambdaVals[idx] + deg1 * lambdaVals[idx + 1],
                        deg2 * gammaVals[idx] + deg1 * gammaVals[idx + 1]
                };
            }
        }
        return new double[]{0.03, 1e-4, 0.85};
    }

    // 主训练函数
    public static void trainModel(String trainFile, String validFile, String testFile) throws IOException {
        List<TensorTuple> trainTuples = readTensorFile(trainFile);
        List<TensorTuple> validTuples = readTensorFile(validFile);
        List<TensorTuple> testTuples = readTensorFile(testFile);

        int[] dims = getTensorDims(trainTuples, validTuples, testTuples);
        int maxX = dims[0], maxY = dims[1], maxZ = dims[2];

        if (!validateTuples(trainTuples, maxX, maxY, maxZ, "train") ||
                !validateTuples(validTuples, maxX, maxY, maxZ, "valid") ||
                !validateTuples(testTuples, maxX, maxY, maxZ, "test")) {
            throw new IllegalArgumentException("Invalid tuples detected.");
        }

        Random rand = new Random();
        double[][] U = new double[maxX][R];
        double[][] W = new double[maxY][R];
        double[][] Z = new double[maxZ][R];
        for (int i = 0; i < maxX; i++) for (int r = 0; r < R; r++) U[i][r] = rand.nextDouble() * 4 - 2;
        for (int j = 0; j < maxY; j++) for (int r = 0; r < R; r++) W[j][r] = rand.nextDouble() * 4 - 2;
        for (int k = 0; k < maxZ; k++) for (int r = 0; r < R; r++) Z[k][r] = rand.nextDouble() * 4 - 2;

        double[][] vU = new double[maxX][R];
        double[][] vW = new double[maxY][R];
        double[][] vZ = new double[maxZ][R];
        double eta_t = 0.03;
        double lambda_t = 1e-4;
        double gamma_t = 0.85;

        double[] initialMetrics = computeRMSEandMAE(trainTuples, U, W, Z);
        double Delta_t = 0.5 * initialMetrics[0] + 0.5 * initialMetrics[1];
        System.out.printf("Initial Delta_0 (normalized): %.10f%n", Delta_t);

        double minValidRMSE = Double.POSITIVE_INFINITY;
        int minValidIterRMSE = 0;
        double minValidMAE = Double.POSITIVE_INFINITY;
        int minValidIterMAE = 0;
        double minTestRMSE = Double.POSITIVE_INFINITY;
        int minTestIterRMSE = 0;
        double minTestMAE = Double.POSITIVE_INFINITY;
        int minTestIterMAE = 0;
        double prevValidRMSE = Double.POSITIVE_INFINITY, prevValidMAE = Double.POSITIVE_INFINITY;
        int patienceCounter = 0;

        try (PrintWriter logFile = new PrintWriter("training_log.txt")) {
            // 写入表头
            logFile.println("valid_rmse::valid_mae::time::test_rmse::test_mae");
            for (int t = 1; t <= MAX_ITER; t++) {
                long startTime = System.nanoTime();

                double[][] U_look = new double[maxX][R];
                double[][] W_look = new double[maxY][R];
                double[][] Z_look = new double[maxZ][R];
                for (int i = 0; i < maxX; i++) for (int r = 0; r < R; r++) U_look[i][r] = U[i][r] + gamma_t * vU[i][r];
                for (int j = 0; j < maxY; j++) for (int r = 0; r < R; r++) W_look[j][r] = W[j][r] + gamma_t * vW[j][r];
                for (int k = 0; k < maxZ; k++) for (int r = 0; r < R; r++) Z_look[k][r] = Z[k][r] + gamma_t * vZ[k][r];

                double[][] gradU = computeGradientU(trainTuples, U_look, W, Z, lambda_t);
                double[][] gradW = computeGradientW(trainTuples, W_look, U, Z, lambda_t);
                double[][] gradZ = computeGradientZ(trainTuples, Z_look, U, W, lambda_t);

                for (int i = 0; i < maxX; i++) for (int r = 0; r < R; r++) vU[i][r] = gamma_t * vU[i][r] - eta_t * gradU[i][r];
                for (int j = 0; j < maxY; j++) for (int r = 0; r < R; r++) vW[j][r] = gamma_t * vW[j][r] - eta_t * gradW[j][r];
                for (int k = 0; k < maxZ; k++) for (int r = 0; r < R; r++) vZ[k][r] = gamma_t * vZ[k][r] - eta_t * gradZ[k][r];

                for (int i = 0; i < maxX; i++) for (int r = 0; r < R; r++) U[i][r] += vU[i][r];
                for (int j = 0; j < maxY; j++) for (int r = 0; r < R; r++) W[j][r] += vW[j][r];
                for (int k = 0; k < maxZ; k++) for (int r = 0; r < R; r++) Z[k][r] += vZ[k][r];

                double[] trainMetrics = computeRMSEandMAE(trainTuples, U, W, Z);
                double Delta_t_new = 0.5 * trainMetrics[0] + 0.5 * trainMetrics[1];
                if (t >= 2) {
                    double I_t = Math.abs(Delta_t_new - Delta_t);
                    double[] hyperparams = adjustHyperparams(I_t);
                    eta_t = hyperparams[0];
                    lambda_t = hyperparams[1];
                    gamma_t = hyperparams[2];
                }
                Delta_t = Delta_t_new;

                double[] validMetrics = computeRMSEandMAE(validTuples, U, W, Z);
                double[] testMetrics = computeRMSEandMAE(testTuples, U, W, Z);
                double elapsedTime = (System.nanoTime() - startTime) / 1e9;

                // 调整打印格式：Valid RMSE::Valid MAE::Time::Test RMSE::Test MAE
                String logLine = String.format("%.6f::%.6f::%.6f::%.6f::%.6f",
                        validMetrics[0], validMetrics[1], elapsedTime, testMetrics[0], testMetrics[1]);
                System.out.println(logLine);
                logFile.println(logLine);

                if (validMetrics[0] < minValidRMSE) {
                    minValidRMSE = validMetrics[0];
                    minValidIterRMSE = t;
                    patienceCounter = 0;
                } else {
                    patienceCounter++;
                }
                if (validMetrics[1] < minValidMAE) {
                    minValidMAE = validMetrics[1];
                    minValidIterMAE = t;
                }
                if (testMetrics[0] < minTestRMSE) {
                    minTestRMSE = testMetrics[0];
                    minTestIterRMSE = t;
                }
                if (testMetrics[1] < minTestMAE) {
                    minTestMAE = testMetrics[1];
                    minTestIterMAE = t;
                }

                if (t >= 5) {
                    double[] last5RMSE = new double[Math.min(t, 5)];
                    for (int i = 0; i < last5RMSE.length; i++) {
                        last5RMSE[i] = validMetrics[0]; // 简化，实际需记录历史值
                    }
                    double maxRMSE = Arrays.stream(last5RMSE).max().getAsDouble();
                    double minRMSE = Arrays.stream(last5RMSE).min().getAsDouble();
                    if (maxRMSE - minRMSE < 0.0005) {
                        eta_t *= 0.5;
                    }
                }

                if (t > MIN_ITER) {
                    if (patienceCounter >= PATIENCE) {
                        System.out.printf("Stopping at iteration %d due to no improvement in %d iterations.%n", t, PATIENCE);
                        break;
                    }
                    if (Math.abs(validMetrics[0] - prevValidRMSE) < TOL && Math.abs(validMetrics[1] - prevValidMAE) < TOL) {
                        System.out.printf("Stopping at iteration %d due to convergence.%n", t);
                        break;
                    }
                }
                prevValidRMSE = validMetrics[0];
                prevValidMAE = validMetrics[1];

                if (t == MAX_ITER) {
                    System.out.println("Reached maximum iterations.");
                }
            }

            System.out.printf("Min Valid RMSE (normalized): %.6f at iteration %d%n", minValidRMSE, minValidIterRMSE);
            System.out.printf("Min Valid MAE (normalized): %.6f at iteration %d%n", minValidMAE, minValidIterMAE);
            System.out.printf("Min Test RMSE (normalized): %.6f at iteration %d%n", minTestRMSE, minTestIterRMSE);
            System.out.printf("Min Test MAE (normalized): %.6f at iteration %d%n", minTestMAE, minTestIterMAE);

            saveMatrix("S.txt", U);
            saveMatrix("D.txt", W);
            saveMatrix("T.txt", Z);
        }
    }

    // 保存矩阵到文件
    private static void saveMatrix(String filename, double[][] matrix) throws IOException {
        try (PrintWriter pw = new PrintWriter(filename)) {
            for (int i = 0; i < matrix.length; i++) {
                for (int r = 0; r < R; r++) {
                    pw.print(hardSigmoid(matrix[i][r]));
                    if (r < R - 1) pw.print(",");
                }
                pw.println();
            }
        }
    }

    public static void main(String[] args) {
        try {
            trainModel(
                    "C:\\Users\\25776\\eclipse-workspace\\dataset_6a_2\\6a_2_tr5.txt",
                    "C:\\Users\\25776\\eclipse-workspace\\dataset_6a_2\\6a_2_val5.txt",
                    "C:\\Users\\25776\\eclipse-workspace\\dataset_6a_2\\6a_2_te90.txt"
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}